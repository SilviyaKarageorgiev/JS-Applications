import { html } from '../../node_modules/lit-html/lit-html.js';

function homeTemplate() {
    return html`
    
    `
}

export function homeView(ctx) {
    ctx.render(homeTemplate());
}